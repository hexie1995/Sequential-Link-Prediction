This is an algorithm developed for temporal network that is based on the previous algorithm introduced in:
https://github.com/Aghasemian/OptimalLinkPrediction
"Stacking Models for Nearly Optimal Link Prediction in Complex Networks", To appear, Proc. Natl. Acad. Sci. USA (2020)
Amir Ghasemian, Homa Hosseinmardi, Aram Galstyan, Edoardo M. Airoldi and Aaron Clauset
